### What is this repository for? ###

Boustrophedon_decompostion is cell decomposition of known map and create right to left and left to right path for each subcell and connect all the cells in shortest distance fashion. And the decomposition is done by finding the obstacle (critical points) where the free space is divides into more regions or combines and forms less regions.

### How do I get set up? ###

Clone it to your workspace and run the function boustrophedon in matlab as
```
boustrophedon('map2.jpg')
```

### Who should I talk to? ###

* Srikanth Malla (smalla@andrew.cmu.edu)

### What project generated the code? ###
Boiler Inspection